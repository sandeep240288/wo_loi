import React from 'react';

function WorkOrder() {
    return (
        <div className="container">
            <div className="row justify-content-center">
                <div className="col-md-8">
                    <div className="card">
                        <div className="card-header">Work Order  Component</div>

                        <div className="card-body">I'm an WorkOrder Componenet!</div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default WorkOrder;

// if (document.getElementById('example')) {
//     ReactDOM.render(<WorkOrder />, document.getElementById('workorder'));
// }
