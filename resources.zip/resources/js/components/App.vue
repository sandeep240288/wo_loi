<script setup>
import NewLoi from './NewLoi.vue'
import { reactive } from 'vue'

const state = reactive({ count: 0 })

function increment() {
    state.count++
}
</script>

<template>


    <NewLoi></NewLoi>
</template>