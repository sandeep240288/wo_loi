import { useState } from 'react';

function NewLoi() {
    const [formData, setFormData] = useState({
        enq_no: '',
        enq_date: '',
        nit_no: '',
        start_date: '',
        end_date: '',
        end_type: '',
        enq_title: '',
        estimatedValue: '',
        offer_validity: '',
        matcat: '',
        contract_period_yr: '',
        contract_period_mo: '',
        contract_period_day: '',
        is_ra: '',
        is_emd: '',
        emd_amt: '',
        is_tender_fee: '',
        tender_fee_amt: '',
        gem_availability: '',
        type_of_bid: '',
        eval_method: '',
        pbg: '',
        is_mi_compliance: '',
        is_bid_split: '',
        manpower_count: '',
        approving_authority: '',
        indent_dept: '',
        indentor: ''
    });

    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setFormData((prevFormData) => ({
            ...prevFormData,
            [name]: value
        }));
    };


    const [errors, setErrors] = useState({});


    const handleSubmit = (event) => {
        event.preventDefault();
        const url = 'loi/store';
        axios.post(url, formData).then(response => {
            console.log(response.data);
        }).catch(errors => {
            var errors = errors.response.data.errors;
            console.log(errors);
        });
        // // validate the form fields here
        // const validationErrors = {};
        // // add validation errors to validationErrors object
        // setErrors(validationErrors);
    };

    return (
        <>
            <h4 className='text-danger m-0'>New LOI</h4>
            <hr />
            <form onSubmit={handleSubmit}>

                <div className="row row row-cols-3">
                    <div className="mb-2">
                        <label htmlFor="enq_no" className="form-label">
                            Enquiry Number
                        </label>
                        <input
                            type="text"
                            className="form-control"
                            id="enq_no"
                            name="enq_no"
                            value={formData.enq_no}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="mb-2">
                        <label htmlFor="enq_date" className="form-label">
                            Enquiry Date
                        </label>
                        <input
                            type="date"
                            className="form-control"
                            id="enq_date"
                            name="enq_date"
                            value={formData.enq_date}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="mb-2">
                        <label htmlFor="nit_no" className="form-label">
                            NIT Number
                        </label>
                        <input
                            type="text"
                            className="form-control"
                            id="nit_no"
                            name="nit_no"
                            value={formData.nit_no}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="mb-2">
                        <label htmlFor="start_date" className="form-label">
                            Start Date
                        </label>
                        <input
                            type="date"
                            className="form-control"
                            id="start_date"
                            name="start_date"
                            value={formData.start_date}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="mb-2">
                        <label htmlFor="end_date" className="form-label">
                            End Date
                        </label>
                        <input
                            type="date"
                            className="form-control"
                            id="end_date"
                            name="end_date"
                            value={formData.end_date}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="mb-2">
                        <label htmlFor="type" className="form-label">
                            Enquiry title
                        </label>
                        <input
                            type="text"
                            className="form-control"
                            id="type"
                            name="type"
                            value={formData.enq_title}
                            onChange={handleInputChange}
                        />
                    </div>

                    
                    <div className="mb-2">
                        <label htmlFor="isTenderType" className="form-label">Tender Type</label>
                        <select
                            className="form-select"
                            id="tender_type"
                            name="tender_type"
                            value={formData.tender_type}
                            onChange={handleInputChange}
                        >
                            <option value="WC">Works Contract</option>
                            <option value="SC">Service Contract</option>
                        </select>
                    </div>

                    

                    <div className="mb-2">
                        <label htmlFor="estimatedValue" className="form-label">
                            Estimated Value
                        </label>
                        <input
                            type="number"
                            className="form-control"
                            id="estimatedValue"
                            name="estimatedValue"
                            value={formData.estimated_value}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="mb-2">
                        <label htmlFor="offerValidity" className="form-label">
                            Offer Validity
                        </label>
                        <input
                            type="number"
                            className="form-control"
                            id="offerValidity"
                            name="offerValidity"
                            value={formData.offerValidity}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="mb-2">
                        <label htmlFor="matcat" className="form-label">
                            Material Category
                        </label>
                        <input
                            type="text"
                            className="form-control"
                            id="matcat"
                            name="matcat"
                            value={formData.matcat}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="mb-2">
                        <label htmlFor="contractPeriod" className="form-label">
                            Contract Period
                        </label>
                        <div className="d-flex">
                            <input
                                type="number"
                                className="form-control me-1"
                                id="contractPeriodYr"
                                name="contract_period_yr"
                                placeholder="Years"
                                value={formData.contract_period_yr}
                                onChange={handleInputChange}
                            />
                            <input
                                type="number"
                                className="form-control me-1"
                                id="contractPeriodMo"
                                name="contract_period_mo"
                                placeholder="Months"
                                value={formData.contract_period_mo}
                                onChange={handleInputChange}
                            />
                            <input
                                type="number"
                                className="form-control"
                                id="contractPeriodDay"
                                name="contract_period_day"
                                placeholder="Days"
                                value={formData.contract_period_day}
                                onChange={handleInputChange}
                            />
                        </div>
                    </div>

                    <div className="mb-2">
                        <label htmlFor="isEmd" className="form-label">Is EMD</label>
                        <select
                            className="form-select"
                            id="is_emd"
                            name="is_emd"
                            value={formData.is_emd}
                            onChange={handleInputChange}
                        >
                            <option value="No">No</option>
                            <option value="Yes">Yes</option>
                        </select>
                    </div>

                    <div className="mb-2">
                        <label htmlFor="emdAmt" className="form-label">
                            EMD Amount
                        </label>
                        <input
                            type="number"
                            className="form-control"
                            id="emd_amt"
                            name="emd_amt"
                            value={formData.emd_amt}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="mb-2">
                        <label htmlFor="isTenderFee" className="form-label">Is Tender Fee</label>
                        <select
                            className="form-select"
                            id="is_tender_fee"
                            name="is_tender_fee"
                            value={formData.is_tender_fee}
                            onChange={handleInputChange}
                        >
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                    </div>

                    <div className="mb-2">
                        <label htmlFor="formTenderFeeAmt" className="form-label">Tender Fee Amount</label>
                        <input type="number" className="form-control" name="tender_fee_amt" value={formData.tender_fee_amt} onChange={handleInputChange} placeholder="Enter tender fee amount" />
                    </div>


                    <div className="mb-2">
                        <label htmlFor="is_ra" className="form-label">Is RA</label>
                        <select
                            className="form-select"
                            id="is_ra"
                            name="is_ra"
                            value={formData.is_ra}
                            onChange={handleInputChange}
                        >
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                    </div>


                    <div className="mb-2">
                        <label htmlFor="formGemAvailability" className="form-label">GEM Availability</label>
                        <select className="form-select" name="gem_availability"
                            value={formData.gem_availability} onChange={handleInputChange}>
                            <option value="">Select GEM Availability</option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="formTypeOfBid" className="form-label">Type of Bid</label>
                        <input type="text" className="form-control" name="type_of_bid" value={formData.type_of_bid} onChange={handleInputChange} placeholder="Enter type of bid" />
                    </div>
                    <div className="mb-2">
                        <label htmlFor="formEvalMethod" className="form-label">Evaluation Method</label>
                        <input type="text" className="form-control" name="eval_method" value={formData.eval_method} onChange={handleInputChange} placeholder="Enter evaluation method" />
                    </div>
                    <div className="mb-2">
                        <label htmlFor="formPbg" className="form-label">PBG</label>
                        <select className="form-select" name="pbg" value={formData.pbg} onChange={handleInputChange}>
                            <option value="">Select PBG</option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="formIsMiCompliance" className="form-label">Is MI Compliance</label>
                        <select className="form-select" name="is_mi_compliance" value={formData.is_mi_compliance} onChange={handleInputChange}>
                            <option value="">Select MI Compliance</option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="formIsBidSplit" className="form-label">Is Bid Split</label>
                        <select className="form-select" name="is_bid_split" value={formData.is_bid_split} onChange={handleInputChange}>
                            <option value="">Select Bid Split</option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                    </div>
                    <div className="mb-2">
                        <label htmlFor="formManpowerCount" className="form-label">Manpower Count</label>
                        <input type="number" className="form-control" name="manpower_count" value={formData.manpower_count} onChange={handleInputChange} placeholder="Enter manpower count" />
                    </div>



                    <div className="form-group mb-2" id="formApprovingAuthority">
                        <label htmlFor="approvingAuthority">Approving Authority</label>
                        <input type="text" name="approving_authority" className="form-control" value={formData.approving_authority} onChange={handleInputChange} />

                    </div>

                    <div className="form-group mb-2" id="formIndentDept">
                        <label htmlFor="indentDept">Indent Dept</label>
                        <input 
                        type="text" 
                        name="indent_dept" 
                        className="form-control" 
                        value={formData.indent_dept} 
                        onChange={handleInputChange} />
                        {errors.indentDept && <small className="text-danger">{errors.indentDept}</small>}
                    </div>

                    <div className="form-group mb-2" id="formIndentor">
                        <label htmlFor="indentor">Indentor</label>
                        <input type="text" name="indentor" className="form-control" value={formData.indentor} onChange={handleInputChange} />
                        {errors.indentor && <small className="text-danger">{errors.indentor}</small>}
                    </div>
                </div>

                <div className='text-center'>
                    <button type='submit' className='btn btn-sm btn-success'>Submit</button>
                </div>
            </form>
        </>
    );

};


export default NewLoi;






