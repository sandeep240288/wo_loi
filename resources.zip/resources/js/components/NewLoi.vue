<script setup>
import { reactive } from 'vue';
const form = reactive({
    enq_no: '',
    enq_date: '',
    nit_no: '',
    start_date: '',
    end_date: '',
    end_type: '',
    enq_title: '',
    estimatedValue: '',
    offer_validity: '',
    matcat: '',
    contract_period_yr: '',
    contract_period_mo: '',
    contract_period_day: '',
    is_ra: '',
    is_emd: '',
    emd_amt: '',
    is_tender_fee: '',
    tender_fee_amt: '',
    gem_availability: '',
    type_of_bid: '',
    eval_method: '',
    pbg: '',
    is_mi_compliance: '',
    is_bid_split: '',
    manpower_count: '',
    approving_authority: '',
    indent_dept: '',
    indentor: ''
});

</script>

<template>
    <h4 class='text-danger m-0'>New LOI</h4>
    <form>

        <div class="row row row-cols-3">
            <div class="mb-2">
                <label htmlFor="enq_no" class="form-label">
                    Enquiry Number
                </label>
                <input type="text" class="form-control" id="enq_no" name="enq_no" v-model="form.enq_no" />
            </div>
            <div class="mb-2">
                <label htmlFor="enq_date" class="form-label">
                    Enquiry Date
                </label>
                <input type="date" class="form-control" id="enq_date" name="enq_date" v-model="form.enq_date" />
            </div>
            <div class="mb-2">
                <label htmlFor="nit_no" class="form-label">
                    NIT Number
                </label>
                <input type="text" class="form-control" id="nit_no" name="nit_no" v-model="form.nit_no" />
            </div>
            <div class="mb-2">
                <label htmlFor="start_date" class="form-label">
                    Start Date
                </label>
                <input type="date" class="form-control" id="start_date" name="start_date" v-model="form.start_date" />
            </div>
            <div class="mb-2">
                <label htmlFor="end_date" class="form-label">
                    End Date
                </label>
                <input type="date" class="form-control" id="end_date" name="end_date" v-model="form.end_date" />
            </div>
            <div class="mb-2">
                <label htmlFor="type" class="form-label">
                    Enquiry title
                </label>
                <input type="text" class="form-control" id="type" name="type" v-model="form.enq_title" />
            </div>


            <div class="mb-2">
                <label htmlFor="isTenderType" class="form-label">Tender Type</label>
                <select class="form-select" id="tender_type" name="tender_type" v-model="form.tender_type">
                    <option value="WC">Works Contract</option>
                    <option value="SC">Service Contract</option>
                </select>
            </div>



            <div class="mb-2">
                <label htmlFor="estimatedValue" class="form-label">
                    Estimated Value
                </label>
                <input type="number" class="form-control" id="estimatedValue" name="estimatedValue"
                    v-model="form.estimated_value" />
            </div>
            <div class="mb-2">
                <label htmlFor="offerValidity" class="form-label">
                    Offer Validity
                </label>
                <input type="number" class="form-control" id="offerValidity" name="offerValidity"
                    v-model="form.offerValidity" />
            </div>
            <div class="mb-2">
                <label htmlFor="matcat" class="form-label">
                    Material Category
                </label>
                <input type="text" class="form-control" id="matcat" name="matcat" v-model="form.matcat" />
            </div>
            <div class="mb-2">
                <label htmlFor="contractPeriod" class="form-label">
                    Contract Period
                </label>
                <div class="d-flex">
                    <input type="number" class="form-control me-1" id="contractPeriodYr" name="contract_period_yr"
                        placeholder="Years" v-model="form.contract_period_yr" />
                    <input type="number" class="form-control me-1" id="contractPeriodMo" name="contract_period_mo"
                        placeholder="Months" v-model="form.contract_period_mo" />
                    <input type="number" class="form-control" id="contractPeriodDay" name="contract_period_day"
                        placeholder="Days" v-model="form.contract_period_day" />
                </div>
            </div>

            <div class="mb-2">
                <label htmlFor="isEmd" class="form-label">Is EMD</label>
                <select class="form-select" id="is_emd" name="is_emd" v-model="form.is_emd">
                    <option value="No">No</option>
                    <option value="Yes">Yes</option>
                </select>
            </div>

            <div class="mb-2">
                <label htmlFor="emdAmt" class="form-label">
                    EMD Amount
                </label>
                <input type="number" class="form-control" id="emd_amt" name="emd_amt" v-model="form.emd_amt" />
            </div>
            <div class="mb-2">
                <label htmlFor="isTenderFee" class="form-label">Is Tender Fee</label>
                <select class="form-select" id="is_tender_fee" name="is_tender_fee" v-model="form.is_tender_fee">
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
            </div>

            <div class="mb-2">
                <label htmlFor="formTenderFeeAmt" class="form-label">Tender Fee Amount</label>
                <input type="number" class="form-control" name="tender_fee_amt" v-model="form.tender_fee_amt"
                    placeholder="Enter tender fee amount" />
            </div>


            <div class="mb-2">
                <label htmlFor="is_ra" class="form-label">Is RA</label>
                <select class="form-select" id="is_ra" name="is_ra" v-model="form.is_ra">
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
            </div>


            <div class="mb-2">
                <label htmlFor="formGemAvailability" class="form-label">GEM Availability</label>
                <select class="form-select" name="gem_availability" v-model="form.gem_availability">
                    <option value="">Select GEM Availability</option>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
            </div>
            <div class="mb-2">
                <label htmlFor="formTypeOfBid" class="form-label">Type of Bid</label>
                <input type="text" class="form-control" name="type_of_bid" v-model="form.type_of_bid"
                    placeholder="Enter type of bid" />
            </div>
            <div class="mb-2">
                <label htmlFor="formEvalMethod" class="form-label">Evaluation Method</label>
                <input type="text" class="form-control" name="eval_method" v-model="form.eval_method"
                    placeholder="Enter evaluation method" />
            </div>
            <div class="mb-2">
                <label htmlFor="formPbg" class="form-label">PBG</label>
                <select class="form-select" name="pbg" v-model="form.pbg">
                    <option value="">Select PBG</option>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
            </div>
            <div class="mb-2">
                <label htmlFor="formIsMiCompliance" class="form-label">Is MI Compliance</label>
                <select class="form-select" name="is_mi_compliance" v-model="form.is_mi_compliance">
                    <option value="">Select MI Compliance</option>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
            </div>
            <div class="mb-2">
                <label htmlFor="formIsBidSplit" class="form-label">Is Bid Split</label>
                <select class="form-select" name="is_bid_split" v-model="form.is_bid_split">
                    <option value="">Select Bid Split</option>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
            </div>
            <div class="mb-2">
                <label htmlFor="formManpowerCount" class="form-label">Manpower Count</label>
                <input type="number" class="form-control" name="manpower_count" v-model="form.manpower_count"
                    placeholder="Enter manpower count" />
            </div>



            <div class="form-group mb-2" id="formApprovingAuthority">
                <label htmlFor="approvingAuthority">Approving Authority</label>
                <input type="text" name="approving_authority" class="form-control" v-model="form.approving_authority" />

            </div>

            <div class="form-group mb-2" id="formIndentDept">
                <label htmlFor="indentDept">Indent Dept</label>
                <input type="text" name="indent_dept" class="form-control" v-model="form.indent_dept" />


                <div class="form-group mb-2" id="formIndentor">
                    <label htmlFor="indentor">Indentor</label>
                    <input type="text" name="indentor" class="form-control" v-model="form.indentor" />

                </div>
            </div>

            <div class='text-center'>
                <button type='submit' class='btn btn-sm btn-success'>Submit</button>
            </div>
        </div>
    </form>
</template>


