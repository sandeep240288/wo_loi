import React from 'react'
import NewLoi from './components/NewLoi.js'
const App = () => {
  return (
    <div>

      <NewLoi />
    </div>
  )
}

export default App