@extends('layouts.app')

@section('content')
<div class="container">

   <div id="app1">
    {{-- Data Rendered from Vue NewLoi --}}
           <App />
    </div>

    
</div>
@endsection
